class CfgPatches
{
	class Loadingscreen
	{
		units[]={};
		weapons[]={};
		requiredVersion=1;
		requiredAddons[]=
		{
			"DZ_Data",
			"DZ_Gear_Consumables",
			"DZ_Vehicles_Wheeled",
			"DZ_Structures_Residential",
			"DZ_Sounds_Effects",
			"DZ_Sounds_Weapons"
		};
	};
};
class CfgMods
{
	class Loadingscreen
	{
		dir="ChaoticHell_Deerisle_Load";
		picture="";
		action="";
		hideName=1;
		hidePicture=1;
		name="ChaoticHell_Deerisle_Load";
		credits="";
		author="ChubbyTheGamer";
		authorID="0";
		version="1.0";
		extra=0;
		type="mod";
		dependencies[]=
		{
			"Game"
		};
		class defs
		{
			class gameScriptModule
			{
				value="";
				files[]=
				{
					"ChaoticHell_Deerisle_Load/scripts/3_Game"
				};
			};
		};
	};
};
